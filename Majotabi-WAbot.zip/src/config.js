export default {
    ownerNumber: ["6281234567890", "238594123935954"], 
    ownerName: "Lipp Majotabi",
    botName: "Majotabi - WAbot",
    thumbnail: "https://cdn.nefusoft.cloud/hwH7h.jpg", 
    subThumbnail: "https://cdn.nefusoft.cloud/1xUI2.jpg", 
    siteUrl: "https://lipz.site",
    sessionName: "session",
    browser: ["Ubuntu", "Chrome", "20.0.04"],
    public: true,
    botLabel: "Aku Jawaa" 
}
